<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class UserController extends Controller
{

    //Register User
    public function store(Request $request)
    {
        $rules = [
            'userid' => 'required|unique:users|max:255',
            'email' => 'required|unique:users',
            'password' => 'required'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return response()->json([
                'success'=>false,
                'error' =>$validator->errors()->toArray()
            ]);
        }

        $user = User::create(
            [
                'userid' => $request->userid,
                'email' => $request->email,
                'password' => Hash::make($request->password)
            ]
        );

        // Change email to username
        $credentials = $request->only('userid', 'password');

        try {
            // attempt to verify the credentials and create a token for the user
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'invalid_credentials'], 401);
            }
        } catch (JWTException $e) {
            // something went wrong whilst attempting to encode the token
            return response()->json(['error' => 'could_not_create_token'], 500);
        }

        // all good so return the token
        return $this->respondWithToken($token);

        //return response()->json($user,201);
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'user' => auth()->user()
        ]);
    }

    public function usersid()
    {
        $usersid = User::select('userid')->orderBy('userid','asc')->get();
        return response()->json([
            'usersid' => $usersid
        ]);
    }
}
